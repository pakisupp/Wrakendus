﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k)]),_(c,l,e,f,g,m,i,[_(c,n,e,f,g,o),_(c,p,e,f,g,q),_(c,r,e,f,g,s,i,[_(c,t,e,f,g,u)]),_(c,v,e,f,g,w),_(c,x,e,f,g,y)])]);}; 
var b="rootNodes",c="pageName",d="Index - Login",e="type",f="Wireframe",g="url",h="Index_-_Login.html",i="children",j="Unustasid parooli?",k="Unustasid_parooli_.html",l="Avaleht",m="Avaleht.html",n="Õppeained",o="Oppeained.html",p="Tegevused",q="Tegevused.html",r="Grupid",s="Grupid.html",t="Vaata grupi infot",u="Vaata_grupi_infot.html",v="Statistika",w="Statistika.html",x="Seaded",y="Seaded.html";
return _creator();
})();
