﻿for(var i = 0; i < 106; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u27'] = 'top';document.getElementById('u93_img').tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u83'] = 'top';document.getElementById('u97_img').tabIndex = 0;

u97.style.cursor = 'pointer';
$axure.eventManager.click('u97', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u77'] = 'top';document.getElementById('u101_img').tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Statistika.html');

}
});
gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';document.getElementById('u103_img').tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u5'] = 'top';document.getElementById('u95_img').tabIndex = 0;

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u37'] = 'top';u88.tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index_-_Login.html');

}
});
gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Avaleht.html');

}
});
