﻿for(var i = 0; i < 7; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u1'] = 'top';