﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m)]),_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w,i,[_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C)]),_(c,D,e,f,g,E),_(c,F,e,f,g,G)])]);}; 
var b="rootNodes",c="pageName",d="Index - Login",e="type",f="Wireframe",g="url",h="Index_-_Login.html",i="children",j="Unustasid parooli?",k="Unustasid_parooli_.html",l="Kasutajaks registreerumine",m="Kasutajaks_registreerumine.html",n="Avaleht",o="Avaleht.html",p="Õppeained",q="Oppeained.html",r="Tegevused",s="Tegevused.html",t="Meetodid",u="Meetodid.html",v="Grupid",w="Grupid.html",x="Loodud grupi detailid",y="Loodud_grupi_detailid.html",z="Liitutud grupi detailid",A="Liitutud_grupi_detailid.html",B="Võõra grupi detailid",C="Voora_grupi_detailid.html",D="Tulemused",E="Tulemused.html",F="Seaded",G="Seaded.html";
return _creator();
})();
