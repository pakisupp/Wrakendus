﻿for(var i = 0; i < 106; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'top';document.getElementById('u16_img').tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u93'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Avaleht.html');

}
});
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u90'] = 'top';document.getElementById('u20_img').tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index_-_Login.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u82'] = 'top';document.getElementById('u12_img').tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u63'] = 'top';document.getElementById('u18_img').tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tulemused.html');

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u80'] = 'top';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
document.getElementById('u14_img').tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u4'] = 'top';