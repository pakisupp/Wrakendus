﻿for(var i = 0; i < 15; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u13'] = 'center';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	NewWindow($axure.globalVariableProvider.getLinkUrl('Unustasid_parooli_.html'), "", "directories=1, height=500, location=1, menubar=1, resizable=1, scrollbars=1, status=1, toolbar=1, width=500", true, 500, 500);

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u8'] = 'center';
u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Avaleht.html');

}
});
gv_vAlignTable['u1'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutajaks_registreerumine.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u11'] = 'center';