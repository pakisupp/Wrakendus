﻿for(var i = 0; i < 110; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u62'] = 'top';u85.tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Index_-_Login.html');

}
});
gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';document.getElementById('u94_img').tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u64'] = 'top';document.getElementById('u100_img').tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u2'] = 'top';document.getElementById('u92_img').tabIndex = 0;

u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u6'] = 'top';document.getElementById('u90_img').tabIndex = 0;

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u101'] = 'top';document.getElementById('u98_img').tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tulemused.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u84'] = 'top';document.getElementById('u96_img').tabIndex = 0;

u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u18'] = 'top';document.getElementById('u88_img').tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Avaleht.html');

}
});
gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u91'] = 'top';