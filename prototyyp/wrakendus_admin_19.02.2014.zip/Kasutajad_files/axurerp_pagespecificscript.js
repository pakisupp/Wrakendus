﻿for(var i = 0; i < 166; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u128'] = 'top';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Statistika.html');

}
});
gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u138'] = 'top';document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u98'] = 'top';document.getElementById('u43_img').tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutaja_detailid.html');

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u40'] = 'top';document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutaja_tulemused.html');

}
});
gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u155'] = 'top';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u64'] = 'top';document.getElementById('u19_img').tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u86'] = 'top';document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u96'] = 'top';document.getElementById('u15_img').tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u12'] = 'top';document.getElementById('u59_img').tabIndex = 0;

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutaja_detailid.html');

}
});
gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u158'] = 'top';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u100'] = 'top';document.getElementById('u13_img').tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutaja_tulemused.html');

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u126'] = 'top';