﻿for(var i = 0; i < 119; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'top';document.getElementById('u51_img').tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupi_tulemused.html');

}
});
gv_vAlignTable['u52'] = 'top';document.getElementById('u16_img').tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u48'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutajad.html');

}
});
gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u118'] = 'top';document.getElementById('u41_img').tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupi_tulemused.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u0'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupi_detailid.html');

}
});
gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u28'] = 'top';document.getElementById('u20_img').tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'top';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u110'] = 'top';document.getElementById('u12_img').tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'top';document.getElementById('u18_img').tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Statistika.html');

}
});
document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupi_detailid.html');

}
});
gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u104'] = 'top';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';document.getElementById('u14_img').tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u4'] = 'top';