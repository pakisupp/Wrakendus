﻿for(var i = 0; i < 74; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutajad.html');

}
});
gv_vAlignTable['u67'] = 'top';document.getElementById('u19_img').tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u49'] = 'top';document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u41'] = 'top';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Statistika.html');

}
});
document.getElementById('u15_img').tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u57'] = 'top';document.getElementById('u13_img').tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u12'] = 'top';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u4'] = 'top';