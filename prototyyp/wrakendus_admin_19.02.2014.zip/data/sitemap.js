﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m)]),_(c,n,e,f,g,o),_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u,i,[_(c,v,e,f,g,w),_(c,x,e,f,g,y)]),_(c,z,e,f,g,A),_(c,B,e,f,g,C)]);}; 
var b="rootNodes",c="pageName",d="Kasutajad",e="type",f="Wireframe",g="url",h="Kasutajad.html",i="children",j="Kasutaja detailid",k="Kasutaja_detailid.html",l="Kasutaja tulemused",m="Kasutaja_tulemused.html",n="Õppeained",o="Oppeained.html",p="Tegevused",q="Tegevused.html",r="Meetodid",s="Meetodid.html",t="Grupid",u="Grupid.html",v="Grupi detailid",w="Grupi_detailid.html",x="Grupi tulemused",y="Grupi_tulemused.html",z="Statistika",A="Statistika.html",B="Seaded",C="Seaded.html";
return _creator();
})();
