﻿for(var i = 0; i < 250; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u38'] = 'top';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Statistika.html');

}
});
gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u205'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u88'] = 'top';document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Kasutajad.html');

}
});
gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u149'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u249'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u167'] = 'top';document.getElementById('u19_img').tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Seaded.html');

}
});
gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u145'] = 'top';document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Tegevused.html');

}
});
gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u237'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u96'] = 'top';document.getElementById('u15_img').tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Grupid.html');

}
});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u12'] = 'top';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Oppeained.html');

}
});
gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'top';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u123'] = 'top';document.getElementById('u13_img').tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Meetodid.html');

}
});
gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u126'] = 'top';